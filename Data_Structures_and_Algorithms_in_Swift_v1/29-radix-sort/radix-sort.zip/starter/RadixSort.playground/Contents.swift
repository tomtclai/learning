// Copyright (c) 2018 Razeware LLC
// For full license & permission details, see LICENSE.markdown.
