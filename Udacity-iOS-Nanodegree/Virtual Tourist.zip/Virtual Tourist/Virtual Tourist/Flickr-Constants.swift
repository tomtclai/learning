//
//  Flickr-Constants.swift
//  Virtual Tourist
//
//  Created by Tom Lai on 1/31/16.
//  Copyright © 2016 Lai. All rights reserved.
//

import Foundation

extension Flickr {
    struct Constants {
        static let ApiKey = ""
        static let BaseUrl = ""
    }
    
    struct Resources {
    }
    
    struct Keys {
    }
    
}