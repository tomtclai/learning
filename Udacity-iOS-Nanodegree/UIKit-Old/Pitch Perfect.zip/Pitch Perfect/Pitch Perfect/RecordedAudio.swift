//
//  RecordedAudio.swift
//  Pitch Perfect
//
//  Created by Tom Lai on 9/23/15.
//  Copyright © 2015 com.udacity. All rights reserved.
//

import Foundation

class RecordedAudio: NSObject {
    var filePathUrl: NSURL!
    var title: String!
    
    init(title: String, filePathUrl: NSURL) {
        self.title = title
        self.filePathUrl = filePathUrl
    }
}


