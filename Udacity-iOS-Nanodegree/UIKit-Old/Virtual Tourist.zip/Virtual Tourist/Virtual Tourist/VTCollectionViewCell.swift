//
//  VTCollectionViewCell.swift
//  Virtual Tourist
//
//  Created by Tom Lai on 2/19/16.
//  Copyright © 2016 Lai. All rights reserved.
//

import UIKit

class VTCollectionViewCell: UICollectionViewCell {
    
    @IBOutlet weak var activity: UIActivityIndicatorView!
}
