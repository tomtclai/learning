//
//  ParseConvenience.swift
//  On The Map
//
//  Created by Tom Lai on 10/10/15.
//  Copyright © 2015 Tom Lai. All rights reserved.
//

import Foundation
extension ParseClient {
    
}