//
//  BNRImageViewController.h
//  HomePwner
//
//  Created by John Gallagher on 1/8/14.
//  Copyright (c) 2014 Big Nerd Ranch. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface BNRImageViewController : UIViewController

@property (nonatomic, strong) UIImage *image;

@end
